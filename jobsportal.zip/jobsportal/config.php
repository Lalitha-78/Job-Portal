<?php
$server='localhost';
$username='root';
$password='';
$database='jobs';
$conn=mysqli_connect($server,$username,$password,$database);
if($conn->connect_error){
    die("Connection failed:".$conn->connect_error);
}
echo"";
if(isset($_POST['register'])){
    $name=$_POST['name'];
    $email=$_POST['email'];
    $number=$_POST['phone'];
    $password=$_POST['password'];


    $sql ="INSERT INTO users(Name,email,password,phone)VALUES ($name,$email,$password,$number)";
    if(mysqli_query($conn,$sql)){
        echo "Records inserted successfully";
    }
    else{
        echo "ERROR:Could not execute $sql".mysqli_error($conn);
    }
}
session_start();
if(isset($_POST['Login'])){
    $email=$_POST['email'];
    $password=$_POST['password'];
    $query= "SELECT * FROM users WHERE 'email'='$email' AND 'password'='$password'";
    $result=mysqli_query($conn,$query);
    $row=mysqli_fetch_array($result,MYSQLI_ASSOC);
    if(mysqli_num_rows($result)==1){
       header("location:index.php"); 
    }
    else{
       $error='emailid or password is incorrect';
    }
}
if(isset($_POST['job'])){
    $cname=$_POST['cname'];
    $position=$_POST['position'];
    $Jobdesc=$_POST['Jobdesc'];
    $skills=$_POST['skills'];
    $CTC=$_POST['CTC'];
    $sql="INSERT INTO `jobs`(`cname`, `position`, `Jobdesc`, `skills`, `CTC`) VALUES ('$cname','$position','$Jobdesc','$skills','$CTC')";
    if(mysqli_query($conn,$sql)){
        echo "New Job is Posted";
    }
    else{
        echo "Failed to post the job $sql".mysqli_error($conn);
    }
 if(isset($_POST['confirm'])) {
    $name=$_POST['name'];
    $qual=$_POST['qual'];
    $apply=$_POST['apply'];
    $year=$_POST['year'];
    $sql="INSERT INTO `candidates`(`name`, `qual`, `year`, `apply`) VALUES ('$name','$qual','$year','$apply')";
    mysqli_query($conn,$sql);
 }  
}

?>